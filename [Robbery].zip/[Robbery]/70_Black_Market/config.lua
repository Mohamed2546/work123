Config_Black_Market = {}

Config_Black_Market.Items = {
    weapons = {
        { label = "أبوعكفه - رشاش كلاش",           item = "weapon_compactrifle", price = 800000, blackMoney = true },
    },
    ammo = {
        { label = "تعبئة طلقات",       item = "boxbig",              price = 4500,   blackMoney = false },
    },
    tools = {
        { label = "أداة كسر",          item = "lockpick",            price = 12500,  blackMoney = true },
        { label = "عدة سرقة الدواجن",  item = "chicken_tool_rob",    price = 25000,  blackMoney = true },
        { label = "عدة سرقة ملابس",    item = "clothes_tool_rob",    price = 25000,  blackMoney = true },
        { label = "عدة سرقة أرامكس",   item = "aramex_tool_rob",     price = 25000,  blackMoney = true },
        { label = "أسيتون",            item = "kq_acetone",          price = 10000,  blackMoney = true },
        { label = "الأمونيا",           item = "kq_ammonia",          price = 10000,  blackMoney = true },
        { label = "إيثنول",             item = "kq_ethanol",          price = 10000,  blackMoney = true },
        { label = "حزمة ليثيوم",       item = "kq_lithium",          price = 10000,  blackMoney = true },
        { label = "بسودوأفيدرين",       item = "kq_pseudo",           price = 10000,  blackMoney = true },
        { label = "عدة تصنيع الميث",   item = "kq_methkit",          price = 30000,  blackMoney = true },

        -- ===== أدوات سطو البنك =====
        { label = "مثقاب",             item = "drill",               price = 35000,  blackMoney = true },
        { label = "حقيبة",             item = "bag",                 price = 15000,  blackMoney = true },
        { label = "قاطع زجاج",         item = "cutter",              price = 20000,  blackMoney = true },
        { label = "قنبلة موقوتة",      item = "c4_bomb",             price = 45000,  blackMoney = true },
        { label = "شحنة حرارية",       item = "thermite_bomb",       price = 40000,  blackMoney = true },
        { label = "لابتوب هاك",        item = "laptop",              price = 30000,  blackMoney = true },
        { label = "فلاشة هاك",         item = "hack_usb",            price = 25000,  blackMoney = true },
    },

    -- ===== قسم البيع (غنائم السطو) =====
    sell = {
        { label = "ذهب",               item = "gold",        price = 85000,  blackMoney = true },
        { label = "ماسة",              item = "diamond",     price = 60000,  blackMoney = true },
        { label = "بوليصة كوكايين",    item = "coke_pooch",  price = 40000,  blackMoney = true },
        { label = "مال أسود",          item = "black_money", price = 1,      blackMoney = false },
        { label = "ماسة فاندياموند",   item = "vandiamond",  price = 320000, blackMoney = true },
        { label = "تمثال فانثر",       item = "vanpanther",  price = 280000, blackMoney = true },
        { label = "عقد نادر",          item = "vannecklace", price = 250000, blackMoney = true },
        { label = "زجاجة نادرة",       item = "vanbottle",   price = 200000, blackMoney = true },
        { label = "تمثال ذهبي",        item = "vanpogo",     price = 220000, blackMoney = true },
        { label = "لوحة فنية G",       item = "paintingg",   price = 300000, blackMoney = true },
        { label = "لوحة فنية F",       item = "paintingf",   price = 300000, blackMoney = true },
    }
}

Config_Black_Market.Locations = {
    {
        coords = vector3(-2184.71, 5202.413, 19.292),
        blip   = true,
        marker = true,
        label  = "السوق السوداء"
    }
}
