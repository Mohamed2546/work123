--[[
    ╔══════════════════════════════════════╗
    ║   70_Black_Market  |  Server         ║
    ║   📌 المطور : ابو خالد               ║
    ╚══════════════════════════════════════╝
--]]

local ESX = exports['es_extended']:getSharedObject()

-- دالة تنسيق الأرقام (server-side)
local function FormatMoney(n)
    local s = tostring(math.floor(n))
    local result = ''
    local count = 0
    for i = #s, 1, -1 do
        count = count + 1
        result = s:sub(i, i) .. result
        if count % 3 == 0 and i ~= 1 then
            result = ',' .. result
        end
    end
    return result
end

-- ============================
-- شراء عنصر
-- ============================
RegisterNetEvent('blackmarket:buyItem')
AddEventHandler('blackmarket:buyItem', function(item)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return end

    -- حماية: تحقق من الكونفيق
    local validItem = false
    for cat, items in pairs(Config_Black_Market.Items) do
        if cat ~= 'sell' then
            for _, v in pairs(items) do
                if v.item == item.item and v.price == item.price then
                    validItem = true; break
                end
            end
        end
        if validItem then break end
    end
    if not validItem then
        xPlayer.showNotification('~r~عنصر غير صالح!')
        return
    end

    local currency = item.blackMoney and 'black_money' or 'money'
    local balance  = xPlayer.getAccount(currency).money

    if balance < item.price then
        xPlayer.showNotification('~r~ما عندك فلوس كافية! تحتاج $' .. FormatMoney(item.price) .. (item.blackMoney and ' مال أسود' or ''))
        return
    end

    xPlayer.removeAccountMoney(currency, item.price)

    if string.find(item.item, 'weapon_') then
        xPlayer.addWeapon(item.item, 50)
    else
        xPlayer.addInventoryItem(item.item, 1)
    end

    xPlayer.showNotification('~g~✅ اشتريت: ' .. item.label)
    print('^2[BlackMarket]^7 ' .. xPlayer.name .. ' اشترى ' .. item.label .. ' بـ $' .. item.price)
end)

-- ============================
-- Callback: الأيتمات القابلة للبيع
-- ============================
ESX.RegisterServerCallback('blackmarket:getSellableItems', function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then cb({}); return end

    local result = {}
    local invMap = {}

    for _, invItem in pairs(xPlayer.getInventory()) do
        if invItem.count > 0 then
            invMap[invItem.name] = invItem.count
        end
    end

    for _, sellItem in pairs(Config_Black_Market.Items.sell) do
        local count = invMap[sellItem.item] or 0
        if count > 0 then
            result[sellItem.item] = count
        end
    end

    cb(result)
end)

-- ============================
-- بيع عنصر
-- ============================
RegisterNetEvent('blackmarket:sellItem')
AddEventHandler('blackmarket:sellItem', function(itemName, itemLabel, itemPrice, amount)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return end

    -- حماية: تحقق من الكونفيق
    local validSell = false
    local realPrice = 0
    for _, v in pairs(Config_Black_Market.Items.sell) do
        if v.item == itemName then
            validSell = true
            realPrice = v.price  -- نأخذ السعر من السيرفر مش من الكلايانت
            break
        end
    end
    if not validSell then
        xPlayer.showNotification('~r~عنصر غير صالح!')
        return
    end

    -- تحقق الكمية
    amount = math.floor(tonumber(amount) or 1)
    if amount < 1 then return end

    local inv = xPlayer.getInventoryItem(itemName)
    if not inv or inv.count < amount then
        xPlayer.showNotification('~r~ما عندك هذا العدد في مخزونك!')
        return
    end

    -- احسب الربح من السيرفر (حماية من التلاعب)
    local totalEarned = amount * realPrice

    -- اسحب الأيتمات وأعطه المال
    xPlayer.removeInventoryItem(itemName, amount)
    xPlayer.addInventoryItem('black_money', totalEarned)

    -- إشعار للاعب
    xPlayer.showNotification('~g~💰 بعت ' .. amount .. 'x ' .. itemLabel .. ' بـ $' .. FormatMoney(totalEarned) .. ' مال أسود!')

    -- رسالة شات للكل
    TriggerClientEvent('chat:addMessage', -1, {
        color     = { 220, 30, 30 },
        multiline = true,
        args      = {
            '🕶️ السوق السوداء',
            ('[ %s ] باع %s × [ %s ] وحصل على $%s مال أسود 💰'):format(
                xPlayer.name,
                amount,
                itemLabel,
                FormatMoney(totalEarned)
            )
        }
    })

    print('^2[BlackMarket]^7 ' .. xPlayer.name .. ' باع ' .. amount .. 'x ' .. itemName .. ' = $' .. totalEarned)
end)
