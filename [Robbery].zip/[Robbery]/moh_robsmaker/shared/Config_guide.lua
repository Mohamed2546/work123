-- مثال على كيفية استخدام النظام الجديد
-- هذا الملف للمرجع فقط ولا يحتاج تشغيل

--[[
    الآن يمكنك تخصيص كل سرقة من ملف config.lua

    مثال على كيفية تعديل إعدادات سرقة معينة:
    
    في config.lua:
    
    Config.RobSettings = {
        ["Chicken"] = {
            cooldown = 1800000, -- 30 دقيقه كولداون على السرقه مره اخرى
            requiredCops = 1,   -- يحتاج شرطي واحد
            distance = 8,       -- مسافة أقل للتفاعل
            participationMarker = {
                enabled = true,
                participationTime = 20, -- 20 ثانية للمشاركة
                key = 74, -- H key
                notificationRadius = 40.0,
                maxParticipants = 3 -- 3 مشاركين فقط
            },
            deliveryOptions = {
                money = {
                    enabled = true,
                    label = "اموال من سرقة الدواجن",
                    reward = {
                        type = "black_money",
                        min = 150000, -- الحد الادنى 
                        max = 250000 -- الاقصى
                    }
                }
            }
        }
    }

    المزايا:
    1. يمكنك تخصيص كل سرقة بسهولة
    2. يمكنك إضافة إعدادات افتراضية للسرقات الجديدة
    3. سهولة في الصيانة والتحديث

    الخصائص المدعومة:
    - cooldown: مدة الانتظار بين السرقات (بالميللي ثانية)
    - requiredCops: عدد الشرطة المطلوب
    - distance: مسافة التفاعل
    - participationMarker: إعدادات ماركر المشاركة
    - deliveryOptions: خيارات المكافآت

    ملاحظة: إذا لم تضع إعدادات لسرقة معينة، ستستخدم الإعدادات الافتراضية
--]]
