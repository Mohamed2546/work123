Config = {}
Config.Settings = {
    Dev = false,
    oldESX = false,
    CityName = "مقاطعة الريف", -- اسم المقاطعة
    logo = "https://f.top4top.io/p_3678ki8l71.png",
    useCooldown = 3000, -- مدة الكولداون بالميللي ثانية (3 ثواني)
    policeAlertBlipTimeout = 200000 -- بلبز اشعار الشرطة كولداون 
}


Config.PoliceJobs = {
    ['police'] = true,
    ['agent'] = true
}

-- إعدادات تفعيل السرقات - يمكنك تفعيل أو إلغاء تفعيل كل سرقة من هنا
Config.EnableRobs = {
    ["Chicken"] = true,        -- سرقة الدواجن
    ["house"] = true,        -- سرقة البيت المهجور
    ["Labs"] = true,           -- سرقة المختبرات  
    ["Electricity"] = true,    -- سرقة الكهرباء
    ["roxwood"] = true,        -- سرقة قصر الجزيرة
    ["mdrazo"] = true,         -- سرقة قصر مدرازو
    ["scrap"] = true,          -- سرقة السكراب
    ["mexican"] = true,        -- سرقة المطعم المكسيكي
    ["Army"] = true,           -- سرقة خزنة الشرطة
    ["BankRob"] = false         -- سرقة البنك
}

-- إعدادات الماركرات
Config.Markers = {
    type = 1,
    size = {x = 1.5, y = 1.5, z = 1.0},
    color = {r = 255, g = 0, b = 0, a = 100},
    bobUpAndDown = false, -- تتحرك فوق وتحت
    faceCamera = false,
    rotate = false
}

-- إعدادات النصوص
Config.Texts = {
    notEnoughCops = "لا يوجد عدد كافٍ من الشرطة متصل",
    robberyInProgress = "السرقة قيد التنفيذ بالفعل",
    robberyOnCooldown = "السرقة في فترة انتظار",
    minigameFailed = "فشلت في المهمة",
    stepCompleted = "تم إكمال الخطوة بنجاح",
    robberyCompleted = "تم إكمال السرقة بنجاح",
    robberyFailed = "فشلت السرقة",
    allRewardsGiven = "تم إعطاء جميع المكافآت"
}

-- Config.RobSettings = {
--     -- إعدادات عامة افتراضية
--     default = {
--         cooldown = 3600000, -- 60 دقيقة افتراضي
--         requiredCops = 0,
--         distance = 10,
--         participationMarker = {
--             enabled = true,
--             participationTime = 30, -- 30 ثانية
--             key = 74, -- H key
--             notificationRadius = 50.0,
--             maxParticipants = 4 -- الحد الأقصى للمشاركين (يشمل السارق الأساسي)
--         },
--         deliveryOptions = {
--             money = {
--                 enabled = true,
--                 label = "اموال غير شرعية",
--                 reward = {
--                     type = "black_money",
--                     min = 250000,
--                     max = 400000
--                 }
--             }
--         }
--     },
    
--     -- إعدادات مخصصة لكل سرقة
--     ["Chicken"] = {
--         cooldown = 1800000, -- 30 دقيقة
--         requiredCops = 0,
--         distance = 8,
--         participationMarker = {
--             enabled = true,
--             participationTime = 20,
--             key = 74,
--             notificationRadius = 40.0,
--             maxParticipants = 3
--         },
--         deliveryOptions = {
--             money = {
--                 enabled = true,
--                 label = "اموال من سرقة الدواجن",
--                 reward = {
--                     type = "black_money",
--                     min = 150000,
--                     max = 250000
--                 }
--             }
--         }
--     },
    
--     ["Labs"] = {
--         cooldown = 2700000, -- 45 دقيقة
--         requiredCops = 2,
--         distance = 12,
--         participationMarker = {
--             enabled = true,
--             participationTime = 40,
--             key = 74,
--             notificationRadius = 60.0,
--             maxParticipants = 5
--         },
--         deliveryOptions = {
--             money = {
--                 enabled = true,
--                 label = "اموال من سرقة المختبرات",
--                 reward = {
--                     type = "black_money",
--                     min = 300000,
--                     max = 500000
--                 }
--             }
--         }
--     },
    
--     ["Electricity"] = {
--         cooldown = 5400000, -- 90 دقيقة
--         requiredCops = 0,
--         distance = 15,
--         participationMarker = {
--             enabled = true,
--             participationTime = 45,
--             key = 74,
--             notificationRadius = 70.0,
--             maxParticipants = 6
--         },
--         deliveryOptions = {
--             money = {
--                 enabled = true,
--                 label = "اموال من سرقة الكهرباء",
--                 reward = {
--                     type = "black_money",
--                     min = 400000,
--                     max = 700000
--                 }
--             }
--         }
--     },
    
--     ["roxwood"] = {
--         cooldown = 4500000, -- 75 دقيقة
--         requiredCops = 2,
--         distance = 12,
--         participationMarker = {
--             enabled = true,
--             participationTime = 35,
--             key = 74,
--             notificationRadius = 55.0,
--             maxParticipants = 4
--         },
--         deliveryOptions = {
--             money = {
--                 enabled = true,
--                 label = "اموال من سرقة قصر الجزيرة",
--                 reward = {
--                     type = "black_money",
--                     min = 350000,
--                     max = 550000
--                 }
--             }
--         }
--     },
    
--     ["mdrazo"] = {
--         cooldown = 5400000, -- 90 دقيقة
--         requiredCops = 3,
--         distance = 15,
--         participationMarker = {
--             enabled = true,
--             participationTime = 40,
--             key = 74,
--             notificationRadius = 65.0,
--             maxParticipants = 5
--         },
--         deliveryOptions = {
--             money = {
--                 enabled = true,
--                 label = "اموال من سرقة فيلا مدرازو",
--                 reward = {
--                     type = "black_money",
--                     min = 450000,
--                     max = 750000
--                 }
--             }
--         }
--     },
    
--     ["scrap"] = {
--         cooldown = 2700000, -- 45 دقيقة
--         requiredCops = 1,
--         distance = 10,
--         participationMarker = {
--             enabled = true,
--             participationTime = 25,
--             key = 74,
--             notificationRadius = 45.0,
--             maxParticipants = 3
--         },
--         deliveryOptions = {
--             money = {
--                 enabled = true,
--                 label = "اموال من سرقة السكراب",
--                 reward = {
--                     type = "black_money",
--                     min = 200000,
--                     max = 350000
--                 }
--             }
--         }
--     },
    
--     ["mexican"] = {
--         cooldown = 3600000, -- 60 دقيقة
--         requiredCops = 2,
--         distance = 10,
--         participationMarker = {
--             enabled = true,
--             participationTime = 30,
--             key = 74,
--             notificationRadius = 50.0,
--             maxParticipants = 4
--         },
--         deliveryOptions = {
--             money = {
--                 enabled = true,
--                 label = "اموال من سرقة المطعم المكسيكي",
--                 reward = {
--                     type = "black_money",
--                     min = 250000,
--                     max = 400000
--                 }
--             }
--         }
--     },
    
--     ["house"] = {
--         cooldown = 1800000, -- 30 دقيقة
--         requiredCops = 0,
--         distance = 8,
--         participationMarker = {
--             enabled = true,
--             participationTime = 5,
--             key = 74,
--             notificationRadius = 40.0,
--             maxParticipants = 2
--         },
--         deliveryOptions = {
            
--             money = {
--                 enabled = true,
--                 label = "اموال من سرقة البيت المهجور",
--                 reward = {
--                     type = "black_money",
--                     min = 100000,
--                     max = 200000
--                 }
--             }
--         }
--     },
    
--     ["Army"] = {
--         cooldown = 7200000, -- 120 دقيقة
--         requiredCops = 4,
--         distance = 20,
--         participationMarker = {
--             enabled = true,
--             participationTime = 60,
--             key = 74,
--             notificationRadius = 100.0,
--             maxParticipants = 8
--         },
--         deliveryOptions = {
--             money = {
--                 enabled = true,
--                 label = "اموال من سرقة خزنة الشرطة",
--                 reward = {
--                     type = "black_money",
--                     min = 800000,
--                     max = 1200000
--                 }
--             }
--         }
--     },
    
--     ["BankRob"] = {
--         cooldown = 10800000, -- 180 دقيقة
--         requiredCops = 6,
--         distance = 25,
--         participationMarker = {
--             enabled = true,
--             participationTime = 90,
--             key = 74,
--             notificationRadius = 150.0,
--             maxParticipants = 10
--         },
--         deliveryOptions = {
--             money = {
--                 enabled = true,
--                 label = "أخذ الأموال نقداً",
--                 reward = {
--                     type = "black_money",
--                     min = 1000000,
--                     max = 2000000
--                 }
--             },
--             items = {
--                 enabled = true,
--                 label = "أخذ سبائك ذهبية",
--                 reward = {
--                     type = "items",
--                     items = {
--                         {name = "gold_bar", label = "سبيكة ذهب", count = {min = 2, max = 5}},
--                         {name = "diamond", label = "ماسة", count = {min = 1, max = 3}}
--                     }
--                 }
--             }
--         }
--     }
-- }

-- إعدادات الأوامر الإدارية
Config.AdminCommands = {
    resetRobbery = "resetrob", -- /resetrob [robberyId]
    startRobbery = "startrob", -- /startrob [robberyId]
    stopRobbery = "stoprob" -- /stoprob [robberyId]
}
