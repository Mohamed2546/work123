local ESX = exports["es_extended"]:getSharedObject()
RegisterNetEvent('moh_robsmaker:policeAlert')
AddEventHandler('moh_robsmaker:policeAlert', function(alertData)
TriggerEvent("moh_notify:SendNotification", {
    text = [[
        <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet">

        <div style="
            font-family: 'Tajawal', sans-serif;
            background-color: rgba(28, 28, 39, 0.85);
            color: #f5f5f5;
            border-radius: 12px;
            padding: 14px 18px;
            border: 1px solid rgba(255, 255, 255, 0.06);
            font-size: 14.2px;
            line-height: 1.6;
            direction: rtl;
            max-width: 270px;
            box-shadow: 0 4px 14px rgba(0, 0, 0, 0.4);
            backdrop-filter: blur(2px);
        ">

            <div style="font-size: 15.5px; font-weight: 700; margin-bottom: 10px; display: flex; align-items: center; gap: 6px;">
                <i class="fas fa-exclamation-circle" style="color: #ff4444;"></i>
                تنبيه أمني
            </div>

            <div style="color: #e0e0e0; margin-bottom: 8px;">
                ]] .. alertData.message .. [[
            </div>

            <div style="font-size: 12.5px; color: #bbb; display: flex; align-items: center; gap: 5px;">
                <i class="fas fa-map-marker-alt" style="color: #f39c12;"></i>
                ]] .. alertData.robberyName .. [[
            </div>
        </div>
    ]],
    type = "error",
    queue = "clean_alert",
    timeout = 9000,
    layout = "centerRight"
})




    
    if alertData.coords then
        local blip = AddBlipForCoord(alertData.coords.x, alertData.coords.y, alertData.coords.z)
        SetBlipSprite(blip, 161)
        SetBlipScale(blip, 1.2)
        SetBlipColour(blip, 1)
        SetBlipAsShortRange(blip, false)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString("🚨 " .. alertData.robberyName)
        EndTextCommandSetBlipName(blip)
        
        Citizen.SetTimeout(Config.Settings.policeAlertBlipTimeout, function()
            if DoesBlipExist(blip) then
                RemoveBlip(blip)
            end
        end)
        
        Citizen.CreateThread(function()
            local flashCount = 0
            while DoesBlipExist(blip) and flashCount < 20 do
                SetBlipFlashes(blip, true)
                Citizen.Wait(500)
                SetBlipFlashes(blip, false)
                Citizen.Wait(500)
                flashCount = flashCount + 1
            end
        end)
    end
end)




RegisterCommand('robberies', function()
    local playerData = ESX.GetPlayerData()
    
    if not Config.PoliceJobs[playerData.job.name] then
        ESX.ShowNotification("هذا الأمر متاح للشرطة فقط")
        return
    end
    
    ESX.TriggerServerCallback('moh_robsmaker:getActiveRobberies', function(activeRobberies)
        if next(activeRobberies) == nil then
            ESX.ShowNotification("لا توجد سرقات نشطة حالياً")
            return
        end
        
        local elements = {}
        for robberyId, state in pairs(activeRobberies) do
            local robbery = System.Robs[robberyId]
            if robbery then
                table.insert(elements, {
                    label = robbery.name .. " (الخطوة: " .. state.step .. "/" .. #robbery.steps .. ")",
                    value = robberyId,
                    step = state.step
                })
            end
        end
        
        ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'active_robberies', {
            title = 'السرقات النشطة',
            align = 'top-left',
            elements = elements
        }, function(data, menu)
            local robberyId = data.current.value
            local robbery = System.Robs[robberyId]
            local state = activeRobberies[robberyId]
            
            if robbery and state then
                local currentStep = robbery.steps[state.step]
                if currentStep then
                    SetNewWaypoint(currentStep.coords.x, currentStep.coords.y)
                    ESX.ShowNotification("تم إضافة نقطة طريق إلى موقع السرقة")
                end
            end
            menu.close()
        end, function(data, menu)
            menu.close()
        end)
    end)
end)
