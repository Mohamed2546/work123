local GamesList = {
    "CircleProgress", "Progress", "KeySpam", "KeyCircle", 
    "NumberSlide", "RapidLines", "CircleShake", "CircleSum",
    "DigitDazzle", "LightsOut", "MineSweeper", "PathFind", "Untangle","arrowPress"
}

-- ═══════════════════════════════════════════════════════════
--                    MINIGAME FUNCTIONS
-- ═══════════════════════════════════════════════════════════

function CircleProgress_Game(difficulty)
    if Config.Settings.Dev then
        print('=== CircleProgress_Game DEBUG ===')
        print('Difficulty: ' .. tostring(difficulty))
    end
    
    difficulty = difficulty or 50
    
    -- Check if bl_ui is available
    if GetResourceState('bl_ui') ~= 'started' then
        if Config.Settings.Dev then
            print('bl_ui not available, simulating CircleProgress success')
        end
        ShowNotification("جاري المعالجة...", "info")
        Citizen.Wait(3000)
        return true -- Simulate success
    end
    
    if Config.Settings.Dev then
        print('Attempting to call bl_ui:CircleProgress...')
    end
    
    -- Try different approaches
    local success, result = pcall(function()
        -- Method 1: Direct export call
        local bl_ui = exports['bl_ui']
        if bl_ui and bl_ui.CircleProgress then
            if Config.Settings.Dev then
                print('Using direct export method')
            end
            return bl_ui:CircleProgress(2, difficulty)
        end
        
        -- Method 2: Using exports table
        if exports.bl_ui then
            if Config.Settings.Dev then
                print('Using exports.bl_ui method')
            end
            return exports.bl_ui:CircleProgress(2, difficulty)
        end
        
        if Config.Settings.Dev then
            print('No bl_ui export found')
        end
        return false
    end)
    
    if Config.Settings.Dev then
        print('CircleProgress pcall success: ' .. tostring(success))
        print('CircleProgress result: ' .. tostring(result))
    end
    
    if success and result ~= nil then
        if Config.Settings.Dev then
            print('CircleProgress completed successfully with result: ' .. tostring(result))
        end
        return result
    else
        if Config.Settings.Dev then
            print('CircleProgress failed or returned nil, using fallback')
        end
        ShowNotification("جاري المعالجة...", "info")
        Citizen.Wait(3000)
        return true -- Fallback to success
    end
end

function Progress_Game(difficulty)
    difficulty = difficulty or 50
    local bl_ui = exports.bl_ui
    return bl_ui:Progress(2, difficulty)
end

function KeySpam_Game(difficulty)
    difficulty = difficulty or 50
    local bl_ui = exports.bl_ui
    return bl_ui:KeySpam(2, difficulty)
end

function KeyCircle_Game(difficulty)
    difficulty = difficulty or 50
    local bl_ui = exports.bl_ui
    return bl_ui:KeyCircle(2, difficulty, 3)
end

function NumberSlide_Game(difficulty)
    difficulty = difficulty or 50
    local bl_ui = exports.bl_ui
    return bl_ui:NumberSlide(2, difficulty, 4)
end

function RapidLines_Game(difficulty)
    difficulty = difficulty or 50
    local bl_ui = exports.bl_ui
    return bl_ui:RapidLines(2, difficulty, 5)
end

function CircleShake_Game(difficulty)
    difficulty = difficulty or 50
    local bl_ui = exports.bl_ui
    return bl_ui:CircleShake(2, difficulty, 3)
end
function arrowPress_Game(difficulty)
    difficulty = difficulty or 50
    local bl_ui = exports.bl_ui
    return bl_ui:ArrowPress(2, difficulty, 3)
end

function CircleSum_Game(difficulty)
    local bl_ui = exports.bl_ui
    return bl_ui:CircleSum(3, {length = 4, duration = 5000})
end

function DigitDazzle_Game(difficulty)
    local bl_ui = exports.bl_ui
    return bl_ui:DigitDazzle(3, {length = 4, duration = 5000})
end

function LightsOut_Game(difficulty)
    local bl_ui = exports.bl_ui
    return bl_ui:LightsOut(3, {level = 2, duration = 5000})
end

function MineSweeper_Game(difficulty)
    if Config.Settings.Dev then
        print('=== MineSweeper_Game DEBUG ===')
        print('Difficulty: ' .. tostring(difficulty))
    end
    
    -- Check if bl_ui is available
    if GetResourceState('bl_ui') ~= 'started' then
        if Config.Settings.Dev then
            print('bl_ui not available, falling back to CircleProgress')
        end
        return CircleProgress_Game(difficulty)
    end
    
    local bl_ui = exports.bl_ui
    if not bl_ui then
        if Config.Settings.Dev then
            print('bl_ui export not found, falling back to CircleProgress')
        end
        return CircleProgress_Game(difficulty)
    end
    
    if Config.Settings.Dev then
        print('Attempting to call bl_ui:MineSweeper...')
    end
    
    local success, result = pcall(function()
        local minigameResult = nil
        local timeout = false
        
        -- Create a timeout thread
        Citizen.CreateThread(function()
            Citizen.Wait(30000) -- 30 second timeout
            timeout = true
        end)
        
        if difficulty == "easy" then
            minigameResult = bl_ui:MineSweeper(2, {grid = 3, duration = 15000, target = 3, previewDuration = 3000})
        elseif difficulty == "medium" then
            minigameResult = bl_ui:MineSweeper(2, {grid = 4, duration = 12000, target = 4, previewDuration = 2500})
        elseif difficulty == "hard" then
            minigameResult = bl_ui:MineSweeper(2, {grid = 5, duration = 10000, target = 5, previewDuration = 2000})
        else
            minigameResult = bl_ui:MineSweeper(2, {grid = 4, duration = 12000, target = 4, previewDuration = 2500})
        end
        
        if timeout then
            if Config.Settings.Dev then
                print('MineSweeper timed out!')
            end
            return false
        end
        
        return minigameResult
    end)
    
    if Config.Settings.Dev then
        print('MineSweeper pcall success: ' .. tostring(success))
        print('MineSweeper result: ' .. tostring(result))
    end
    
    if success then
        if Config.Settings.Dev then
            print('MineSweeper completed successfully')
        end
        return result
    else
        if Config.Settings.Dev then
            print('MineSweeper failed, falling back to CircleProgress: ' .. tostring(result))
        end
        return CircleProgress_Game(difficulty)
    end
end

function PathFind_Game(difficulty)
    local bl_ui = exports.bl_ui
    return bl_ui:PathFind(3, {numberOfNodes = 10, duration = 5000})
end
function Untangle_Game(difficulty)
    local bl_ui = exports.bl_ui
    return bl_ui:Untangle(1, {numberOfNodes = 6, duration = 5000})
end

function Plant_Game(difficulty)
    local playerPed = PlayerPedId()
    local coords = GetEntityCoords(playerPed)
    
    RequestAnimDict("anim@heists@ornate_bank@thermal_charge")
    while not HasAnimDictLoaded("anim@heists@ornate_bank@thermal_charge") do
        Citizen.Wait(50)
    end
    
    local bombModel = GetHashKey("prop_bomb_01_s")
    RequestModel(bombModel)
    while not HasModelLoaded(bombModel) do
        Citizen.Wait(50)
    end
    
    TaskPlayAnim(playerPed, "anim@heists@ornate_bank@thermal_charge", "thermal_charge", 8.0, -8.0, 4000, 16, 0, false, false, false)
    
    if Config.Settings.Dev then
        print("جاري زرع القنبلة...")
    end
    
    Citizen.Wait(2000)
    
    local forwardVector = GetEntityForwardVector(playerPed)
    local bombCoords = coords + forwardVector * 0.5
    local bombObject = CreateObject(bombModel, bombCoords.x, bombCoords.y, bombCoords.z + 0.5, true, true, false)
    
    local playerHeading = GetEntityHeading(playerPed)
    SetEntityHeading(bombObject, playerHeading)

    
    Citizen.Wait(2000)
    
    ClearPedTasks(playerPed)
    
    if not _G.PlantedBombs then
        _G.PlantedBombs = {}
    end
    table.insert(_G.PlantedBombs, bombObject)
    
    return true
end

function Drill_Game(difficulty)
    local playerPed = PlayerPedId()
    local coords = GetEntityCoords(playerPed)
    
    RequestAnimDict("anim@heists@fleeca_bank@drilling")
    while not HasAnimDictLoaded("anim@heists@fleeca_bank@drilling") do
        Citizen.Wait(50)
    end
    
    local drillModel = GetHashKey("hei_prop_heist_drill")
    RequestModel(drillModel)
    while not HasModelLoaded(drillModel) do
        Citizen.Wait(50)
    end
    
    local forwardVector = GetEntityForwardVector(playerPed)
    local drillCoords = coords + forwardVector * 0.5
    local drillObject = CreateObject(drillModel, drillCoords.x, drillCoords.y, drillCoords.z, true, true, false)
    
    local playerHeading = GetEntityHeading(playerPed)
    SetEntityHeading(drillObject, playerHeading)
    
    TaskPlayAnim(playerPed, "anim@heists@fleeca_bank@drilling", "drill_straight_idle", 8.0, -8.0, 8000, 16, 0, false, false, false)
    
    
    ShowNotification("جاري دريل الخزنة... انتظر!", "info")
    
    local durationMs = 8000
    local startTime = GetGameTimer()
    
    Citizen.CreateThread(function()
        while GetGameTimer() - startTime < durationMs do
            DrawLightWithRange(drillCoords.x, drillCoords.y, drillCoords.z + 0.5, 255, 165, 0, 2.0, 0.5)
            Citizen.Wait(100)
        end
    end)
    
    Citizen.Wait(durationMs)
    
    ClearPedTasks(playerPed)
    
    if DoesEntityExist(drillObject) then
        DeleteObject(drillObject)
    end
    
    
    ShowNotification("تم حفر الخزنة بنجاح!", "success")
    
    return true
end

-- ═══════════════════════════════════════════════════════════
--                    MAIN FUNCTIONS
-- ═══════════════════════════════════════════════════════════

function StartMinigame(gameType, difficulty)
    if Config.Settings.Dev then
        print('=== MINIGAME DEBUG ===')
        print('Game Type: ' .. tostring(gameType))
        print('Difficulty: ' .. tostring(difficulty))
        print('bl_ui state: ' .. GetResourceState('bl_ui'))
    end
    
    if Config.Settings.Dev then
        return true
    end
    if not gameType or gameType == "random" then
        gameType = GamesList[math.random(1, #GamesList)]
    end
    if gameType == "none" then
        if Config.Settings.Dev then
            print('minigame none')
        end
        return true
    end
    local gameExists = false
    for _, game in ipairs(GamesList) do
        if game == gameType then
            gameExists = true
            break
        end
    end
    
    if not gameExists then
        if Config.Settings.Dev then
            print('minigame not found: ' .. tostring(gameType))
        end
        return false
    end

    if Config.Settings.Dev then
        print('minigame playing: ' .. gameType)
    end
    Citizen.Wait(500) -- Reduced wait time
    
    local success = false
    
    if gameType == "CircleProgress" then
        success = CircleProgress_Game(difficulty)
    elseif gameType == "Progress" then
        success = Progress_Game(difficulty)
    elseif gameType == "KeySpam" then
        success = KeySpam_Game(difficulty)
    elseif gameType == "KeyCircle" then
        success = KeyCircle_Game(difficulty)
    elseif gameType == "NumberSlide" then
        success = NumberSlide_Game(difficulty)
    elseif gameType == "RapidLines" then
        success = RapidLines_Game(difficulty)
    elseif gameType == "arrowPress" then
        success = arrowPress_Game(difficulty)
    elseif gameType == "CircleShake" then
        success = CircleShake_Game(difficulty)
    elseif gameType == "CircleSum" then
        success = CircleSum_Game(difficulty)
    elseif gameType == "DigitDazzle" then
        success = DigitDazzle_Game(difficulty)
    elseif gameType == "LightsOut" then
        success = LightsOut_Game(difficulty)
    elseif gameType == "MineSweeper" then
        if Config.Settings.Dev then
            print('Starting MineSweeper...')
        end
        success = MineSweeper_Game(difficulty)
        if Config.Settings.Dev then
            print('MineSweeper finished with result: ' .. tostring(success))
        end
    elseif gameType == "PathFind" then
        success = PathFind_Game(difficulty)
    elseif gameType == "Untangle" then
        success = Untangle_Game(difficulty)
    elseif gameType == "plant" then
        success = Plant_Game(difficulty)
    elseif gameType == "drill" then
        success = Drill_Game(difficulty)
    else
        if Config.Settings.Dev then
            print('Unknown minigame type: ' .. tostring(gameType))
        end
        success = true 
    end

    if Config.Settings.Dev then
        print('Minigame result: ' .. tostring(success))
        print('=== END MINIGAME DEBUG ===')
    end

    return success
end

exports('StartMinigame', StartMinigame)

--[[ 
═══════════════════════════════════════════════════════════
                    أمثلة للاستخدام:
═══════════════════════════════════════════════════════════

-- 1. تشغيل عادي:
StartMinigame()                      -- عشوائي
StartMinigame("CircleProgress")      -- محدد
StartMinigame("KeySpam", 75)         -- مع صعوبة
]]